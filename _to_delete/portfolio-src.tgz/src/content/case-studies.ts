import type { CaseStudy } from "./types";

/*
 * Source of truth: sentry/02-career/portfolio-enhancement/*.md (as of 2026-09-24).
 * Public-safe rules applied from case-study-framework.md:
 *  - clients anonymized (no client or client-product names)
 *  - employer named once per study, as attribution only
 *  - no internal codenames, file keys or repo names
 *  - metrics are team-observed and labelled as such
 *  - every visual is a demo brand or a redrawn diagram, never a client screen;
 *    client product screens are rebuilt in HTML from the design files
 *    (screens.ts). Real captures are used only for my own product (Blinkwiser)
 *    and for the publicly published Dubai Municipality app.
 */

export const caseStudies: CaseStudy[] = [
  /* ------------------------------------------------------------------ 01 */
  {
    slug: "open-enrollment",
    index: "01",
    glyph: "flow",
    group: "Health insurance platforms",
    title: "Health-insurance enrollment, from 9 steps to 5",
    short: "Health-insurance enrollment",
    dek: "Members kept telling us enrollment was too long. When I walked through it, I found it asked questions in the order the backend stores them, so I rebuilt it around how a family actually decides.",
    meta: {
      role: "UX Lead",
      context: "Mphasis · US health-insurance platform",
      timeline: "Live in production",
      domain: "Enterprise SaaS · US health insurance",
    },
    tags: ["US health insurance", "Decision modeling", "Defaults", "Regulated flows"],
    cover: {
      video: "/work/enrollment/trailer.mp4",
      poster: "/work/enrollment/trailer-poster.webp",
      sound: true,
      bare: true,
      alt: "Trailer of the enrollment redesign. Old flow: Dennis adds his newborn and is told she isn't covered. He goes through a coverage hub and re-adds his family inside the Medical plan. He sees only an annual estimate. He loses his family list when he changes plan. New flow: one grid sets who needs what. There's no hub. Each plan already knows who it covers. Prices are monthly, with a running total. Switching plans keeps the family.",
    },
    headline: { value: "5 steps", label: "down from 9, with “who's covered” asked once" },
    opener: {
      scope: "One flow that runs three kinds of enrollment: open enrollment, life events and new hires.",
      note: "Dennis is a persona I use to tell the story, and these are illustrations rather than the shipped screens. I counted the steps by walking through the old and new flows, and the prices are made up for the demo.",
      stories: [
        {
          id: "newborn",
          tab: "Adding dependents",
          story: "Dennis just had a baby, and he has 31 days to get her covered.",
          quote: "Adding a dependent does not automatically enroll them in coverage.",
          quoteSource: "The old flow, right after he added her",
          visual: "newborn",
          caption: "In the old flow, adding his daughter and covering her were two separate jobs, and every coverage added another step. In the redesign he does both in the same row."
        },
        {
          id: "plan-switch",
          tab: "Switching plans",
          story: "Dennis switches to a cheaper dental plan, and the old flow forgets his family.",
          quote: "Select Member(s)/Dependent(s) to cover",
          quoteSource: "The old plan page, asking again after he changed plans",
          visual: "plan-switch",
          caption: "The old flow tied the family to the plan, so a new plan meant building the family list all over again. In the redesign the family stays with Dennis whichever plan he picks.",
        },
        {
          id: "cost",
          tab: "Visible cost",
          story: "Dennis picks plans for six people and never once sees the total.",
          quote: "The displayed Premium is only an estimate. The amount may vary if you change network or update Dependents.",
          quoteSource: "Printed under every price in the old flow",
          visual: "cost",
          caption: "Each plan showed its own price and nothing added them up. Now there's a running total at the top of every coverage screen.",
        },
      ],
    },
    hero: {
      label: "Regulated decision flow",
      brief: "The enrollment flow is too long.",
      problem: "It asked questions in the order the backend stores them.",
      call: "Reorder the questions to match how a family actually decides.",
    },
    snapshot: {
      frame:
        "The brief was simple: users said enrollment took too long. When I walked through it myself, I saw why. It followed the way the backend stores data, so members had to answer “who's covered” again inside every single coverage.",
      decision:
        "Instead of cutting screens, I changed the order of the questions to match how a family thinks: first my family, then who needs what, then which plan. “Who needs what” is now asked once, in a single grid of family members against coverages.",
      outcome:
        "The flow went from 9 steps to 5, the loop for every coverage is gone, and members can see the cost at every step. It's now live for open enrollment, life events and new hires.",
    },
    frame: {
      assumed: "The flow is too long, so trim some screens.",
      actual: "It asked questions in the order the backend stores them, so members kept answering the same question.",
      body: [
        "The feedback came from users and from our business analysts, and it boiled down to four things. The flow felt too long, members got confused about dependents, they didn't see the cost until late, and admins struggled when they enrolled people on their behalf.",
        "The obvious fix was to trim screens, but I wanted to know why there were so many first. Cutting screens would have made the loop shorter without getting rid of it.",
      ],
      evidence: {
        title: "The backend's data model, turned straight into screens",
        items: [
          "Three screens just to manage the household: the list, an add form, then the updated list.",
          "A loop for every coverage: pick Medical, browse plans, pick one, choose who it covers, go back to the hub, then do it all again for Dental and Vision.",
          "So members answered “who's covered” twice, once for the household and again inside every coverage.",
          "The premium was shown as a yearly estimate, and it could still change if they edited dependents or the network.",
        ],
      },
      exhibit: "flow-compare",
    },
    stakes: {
      intro: "Open enrollment happens once a year. A life event like a birth opens a short window, usually 30 or 31 days, and if you miss it, adding someone usually has to wait for the next open enrollment.",
      items: [
        { title: "Missed family members", body: "If someone gets missed on one coverage, they stay uncovered until the next window or another qualifying life event." },
        { title: "Late cost", body: "If the cost only shows up at the end, members commit before they know what they'll pay." },
        { title: "Admins hit the same problems", body: "Admins enroll members on their behalf, so every weakness in the member flow hits them too." },
      ],
      exhibit: "coverage-gap",
    },
    forks: [
      {
        id: "reorder",
        title: "I changed the order of the questions instead of trimming screens",
        tension: "Trimming would have been quicker, and on paper it would have answered “too long”.",
        rejected: { label: "Trim screens", detail: "Keeps the loop, and members still answer the dependent question twice." },
        chosen: { label: "Reorder the decision", detail: "First my family, then who needs what, then which plan." },
        why: [
          "Now “who needs what” is asked once, as a grid of family members against coverage types. Picking plans builds on that grid instead of asking the same thing again for every coverage.",
        ],
        cost: "The new order didn't match how the backend stored enrollments anymore, and that turned into decision 3.",
        exhibit: "trim-vs-reorder",
      },
      {
        id: "defaults",
        title: "I made the most common choice the default",
        tension: "Once the grid was in place, most of the remaining work was picking plans.",
        rejected: { label: "Ask everything, every time", detail: "Treats the rare paths the same as the common one." },
        chosen: { label: "Design the defaults", detail: "A shared family plan by default, with a clear way to pick plans per member." },
        why: [
          "Keeping your current plan is the default, and waiving coverage sits right there on the screen instead of being tucked away.",
          "My bet was simple: the most common path should be the shortest, and the less common one should still be one clear step away.",
        ],
        cost: "In a regulated flow a default carries real weight, so I made sure every one stayed visible and easy to change.",
        exhibit: "coverage-grid",
      },
      {
        id: "engineering",
        title: "I let the UI translate for the backend, and we changed the backend in phases",
        tension:
          "Engineering pushed back, and fairly. Their model went coverage, then plan, then members, and I was asking them to take the answers in the reverse order.",
        rejected: { label: "Either extreme", detail: "Either show members the backend's order, or demand a backend rewrite." },
        chosen: { label: "Translate, then phase", detail: "The UI collects the grid and translates it, and the backend changes only where translating isn't enough." },
        why: [
          "I walked engineering through the order a member makes these decisions in, side by side with the actual complaints from users. We split the work and shipped it in phases rather than switching everything over at once.",
        ],
        cost: "The rollout was slower, but engineering owned the change instead of fighting it.",
        exhibit: "translate-layer",
      },
    ],
    followOn: {
      title: "What followed from the new order",
      intro: "These were my calls too, and each one only worked because the questions now came in the right order.",
      items: [
        {
          title: "Cost where the decision is made",
          body: "A running total on every step, shown per month or per paycheck deduction, instead of a yearly estimate at the very end.",
        },
        {
          title: "One review page before signing",
          body: "One page to check everything before a commitment that lasts a year. You can see what changed, edit it right there, and accept the disclaimer and e-sign in the same step.",
        },
        {
          title: "Ask only when needed",
          body: "Document upload used to be a fixed step for everyone. Now it only shows up when a member's situation actually needs a document.",
        },
      ],
      exhibit: "ask-when-needed",
    },
    spotlight: {
      label: "The admin side",
      title: "Passive enrollment: the members who never open the flow",
      intro:
        "Members who do nothing during open enrollment used to be handled by admins, one person at a time. I designed a rule that each employer sets up once and runs themselves, with a record of every run and a list of the members the rule couldn't handle.",
      why: [
        "When members took no action during open enrollment, admins had to sort them out by hand, one at a time.",
        "Every employer has its own rule for these members. Some terminate them, some carry the current plan forward and some move them to a default plan, sometimes depending on eligibility.",
        "And it all lands at the deadline of a once-a-year window, where a missed member stays uncovered until the next window or a qualifying life event.",
      ],
      what: [
        "A Passive Enrollment tab in each employer's enrollment settings, with four rules written in plain language. Each rule only shows the options it needs.",
        "Fields for termination status and reason, a way to leave out members who have supplemental products, and a default-plan mapping file with a template admins can download.",
        "Admins can save, or save and run right away. Before a run they see the rule, the file and how many members it will affect, with a plain warning that it can't be undone. The settings lock while a run is going.",
        "A log of every run, plus a report that separates the members who were processed from the ones who need a look, each with a reason and Enroll or Terminate buttons right in the row.",
        "The business owned the rules. My part was how admins set them up, run them and deal with the cases a rule can't decide.",
      ],
      impact: [
        "What used to be a manual job, done member by member, is now a rule each employer's admin sets once and runs themselves.",
        "Every run leaves a record of who ran it, when, with which rule and file, and how many members it touched.",
        "Members a rule can't handle don't get lost in the batch anymore. They come back with a reason, and the admin sorts them out right there.",
      ],
      provenance: "These results are qualitative. We didn't measure the effort before and after.",
      lead: "passive-funnel",
      exhibit: "passive-screens",
    },
    outcome: {
      metrics: [
        {
          value: "5 steps",
          label: "Down from 9: Welcome, Profile, Dependents, Coverage, Review",
          before: { label: "9 steps", amount: 9 },
          after: { label: "5 steps", amount: 5 },
          unit: "steps",
          visual: "glyph-flow",
        },
        { value: "Once", label: "“Who's covered” is asked once, instead of once for every coverage", visual: "asked-once" },
        { value: "Every step", label: "Cost is visible, shown the way people actually pay it", visual: "cost-every-step" },
        { value: "4 flows", label: "One flow structure shared by open enrollment, life events, new hires and admins enrolling on someone's behalf", visual: "four-flows" },
      ],
      points: [
        "It's live in production. The complaints that started the redesign have dropped, and admins enrolling on someone's behalf get through it faster.",
      ],
      provenance: "These are early signals we've seen, not formal measurements yet.",
      exhibit: "enrollment-screens",
    },
    ownership: {
      mine: [
        "I owned the reframe, the new order of questions, the family-plan default, the running monthly total and the single review page you can edit.",
      ],
      shared: [
        "Using one flow structure for every enrollment type and every kind of user was a decision I made with product and engineering. I also designed the admin screens for passive enrollment, while the business owned the rules behind them.",
      ],
      change: [
        "I'd get evidence in earlier. The redesign was based on feedback from users and business analysts plus my own analysis of the flow, not on watching real members use it. I'd also add tracking to the old flow before changing anything, so I could show the improvement in numbers instead of only describing it.",
      ],
    },
    story: {
      chapters: [
        {
          id: "brief",
          rail: "The brief",
          title: "Everyone said the flow was too long",
          blocks: [
            { kind: "p", text: "The feedback reached me from two places, users and our business analysts, and it boiled down to four complaints. The enrollment flow felt too long, members got confused about dependents, they didn't see the cost until late, and admins struggled whenever they enrolled someone on a member's behalf." },
            { kind: "p", text: "The obvious fix was to trim a few screens. Before doing that, I wanted to know why there were so many in the first place, so I walked through the whole flow step by step, the way a member would." },
            { kind: "exhibit", id: "flow-compare" },
            { kind: "p", text: "What I found was the backend's data model, turned straight into screens. It took three screens just to manage the household. Then every coverage had its own loop: pick Medical, browse plans, pick one, choose who it covers, go back to the hub, and do it all again for Dental and Vision. So members answered “who's covered” once for the household and again inside every coverage, and the price they saw was a yearly estimate that could still change." },
            { kind: "reframe", assumed: "The flow is too long, so trim some screens.", actual: "It asked questions in the order the backend stores them, so members kept answering the same question." },
            { kind: "p", text: "Cutting screens would have made that loop shorter, but members would still be answering the same question over and over. The real problem was the order of the questions." },
          ],
        },
        {
          id: "stakes",
          rail: "Why it matters",
          title: "Why a missed step matters so much here",
          blocks: [
            { kind: "p", text: "Open enrollment happens once a year. A life event like a birth opens a much shorter window, usually 30 or 31 days, and if someone gets missed in that window, adding them usually has to wait until the next open enrollment." },
            { kind: "exhibit", id: "coverage-gap" },
            { kind: "p", text: "So the problems in this flow weren't small annoyances. A family member missed on one coverage stayed uncovered until the next window. When the cost only showed up at the end, people committed before they knew what they'd pay. And because admins enroll members on their behalf, every weakness in the member flow hit them too." },
          ],
        },
        {
          id: "reorder",
          rail: "Decision 1: the order",
          title: "I changed the order of the questions instead of trimming screens",
          blocks: [
            { kind: "p", text: "Trimming would have been the quicker fix, and on paper it would have answered “too long”. But it would have kept the loop, and members would still answer the dependent question twice." },
            { kind: "exhibit", id: "trim-vs-reorder" },
            { kind: "p", text: "So I reordered the flow to follow how a family actually thinks it through: first my family, then who needs what, then which plan. “Who needs what” is now asked once, in one grid with family members down the side and coverages across the top. Picking plans builds on that grid instead of asking the same thing again for every coverage." },
            { kind: "note", label: "What it cost", text: "The new order didn't match how the backend stored enrollments anymore. That turned into my third decision." },
          ],
        },
        {
          id: "defaults",
          rail: "Decision 2: defaults",
          title: "I made the most common choice the default",
          blocks: [
            { kind: "p", text: "Once the grid was in place, most of the remaining work was picking plans. If I treated every path the same, the rare cases would get as much screen space as the common one, so I designed the defaults on purpose." },
            { kind: "p", text: "A shared family plan is the default, with a clear way to pick plans per member when someone needs that. Keeping your current plan is the default too, and waiving coverage sits right there on the screen instead of being tucked away. My bet was simple: the most common path should be the shortest, and the less common one should still be one clear step away." },
            { kind: "exhibit", id: "coverage-grid" },
            { kind: "note", label: "What it cost", text: "In a regulated flow a default carries real weight, so I made sure every one stayed visible and easy to change." },
          ],
        },
        {
          id: "engineering",
          rail: "Decision 3: engineering",
          title: "When engineering pushed back",
          blocks: [
            { kind: "p", text: "Engineering pushed back, and they had a fair point. Their model went coverage, then plan, then members, and I was asking them to take the answers in the reverse order." },
            { kind: "p", text: "I didn't want to push the backend's order back onto members, and asking for a full backend rewrite wasn't realistic either. So I walked the team through the order a member makes these decisions in, side by side with the actual complaints from users." },
            { kind: "exhibit", id: "translate-layer" },
            { kind: "p", text: "We landed on a middle path. The UI collects the grid and translates it for the backend, and the backend changes only where translating isn't enough. We split the work and shipped it in phases instead of switching everything over at once." },
            { kind: "note", label: "What it cost", text: "The rollout was slower, but engineering owned the change instead of fighting it." },
          ],
        },
        {
          id: "follow-on",
          rail: "What followed",
          title: "Small things the new order made possible",
          blocks: [
            { kind: "p", text: "Once the questions came in the right order, a few other improvements became possible. These were my calls too." },
            {
              kind: "cards",
              items: [
                { title: "Cost where you decide", body: "A running total on every step, shown per month or per paycheck deduction, instead of a yearly estimate at the very end." },
                { title: "One review page before signing", body: "One page to check everything before a commitment that lasts a year. You can see what changed, edit it right there, and accept the disclaimer and e-sign in the same step." },
                { title: "Documents only when needed", body: "Document upload used to be a fixed step for everyone. Now it only shows up when a member's situation actually needs a document." },
              ],
            },
            { kind: "exhibit", id: "ask-when-needed" },
          ],
        },
        {
          id: "admins",
          rail: "The admin side",
          title: "The members who never open the flow",
          blocks: [
            { kind: "p", text: "Every open enrollment, some members do nothing at all. Admins used to sort them out by hand, one member at a time, and every employer had its own rule for them. Some terminate those members, some carry the current plan forward and some move them to a default plan, sometimes depending on eligibility. All of it landed right at the deadline, where a missed member stays uncovered until the next window." },
            { kind: "p", text: "The business owned those rules. My part was designing how admins set them up, run them and deal with the cases a rule can't decide. Each employer now has a Passive Enrollment tab with four rules written in plain language. Before a run, the admin sees the rule, the file and how many members it will affect, with a plain warning that it can't be undone." },
            { kind: "exhibit", id: "passive-funnel" },
            { kind: "p", text: "Every run leaves a record of who ran it, when, and with which rule and file. The report separates the members who were processed from the ones who need a look, and those come back with a reason and Enroll or Terminate buttons right in the row, so nobody gets lost in the batch. We didn't measure the effort before and after, but a job that used to be done member by member is now a rule each employer sets once." },
            { kind: "exhibit", id: "passive-screens" },
          ],
        },
        {
          id: "outcome",
          rail: "What changed",
          title: "What changed",
          blocks: [
            { kind: "p", text: "The new flow is live in production for open enrollment, life events and new hires, and admins use the same structure when they enroll someone on a member's behalf. It went from 9 steps to 5: Welcome, Profile, Dependents, Coverage and Review." },
            { kind: "metrics" },
            { kind: "p", text: "The complaints that started the redesign have dropped, and admins get through enrolling on someone's behalf faster. To be honest, these are signals we've seen rather than formal measurements, which is something I'd fix next time." },
            { kind: "exhibit", id: "enrollment-screens" },
          ],
        },
        {
          id: "next-time",
          rail: "Next time",
          title: "What I'd do differently",
          blocks: [
            { kind: "p", text: "I'd get evidence in earlier. The redesign was based on feedback from users and business analysts plus my own analysis of the flow, not on watching real members use it. I'd also add tracking to the old flow before changing anything, so I could show the improvement in numbers instead of only describing it." },
            { kind: "p", text: "To be clear about who did what: the reframe, the new order of questions, the family-plan default, the running monthly total and the single review page were my calls. Using one flow structure for every enrollment type was a decision I made with product and engineering, and the business owned the rules behind passive enrollment." },
          ],
        },
      ],
    },
    signals:
      "This project shows how I work: I fixed the order of the decisions instead of the screens, brought engineering round to the member's way of thinking without asking for a rewrite, and chose every default on purpose.",
  },
  /* ------------------------------------------------------------------ 02 */
  {
    slug: "enterprise-platform-from-zero",
    index: "02",
    glyph: "tiers",
    group: "Health insurance platforms",
    title: "Building an enterprise health-insurance platform from zero",
    short: "White-label platform",
    dek: "Asked to adjust a few screens, I found a white-label product with no system, where every new client was a rebuild.",
    meta: {
      role: "Founding UX Designer, now UX Lead",
      context: "Mphasis · US health-insurance platform",
      timeline: "2021–now",
      domain: "Enterprise SaaS · US health insurance",
    },
    tags: ["US health insurance", "Three-tier tokens", "White-label", "Design system adoption"],
    cover: {
      screen: "ds-dashboard",
      alt: "Member dashboard page pattern from the design system: coverage status by family member, claims status, resources, and find care.",
      caption: "A member dashboard pattern from the library. Every client sees it in its own brand.",
    },
    headline: { value: "< 24 h", label: "to theme a new client, down from weeks (team-observed)" },
    card: { title: "White-label health-insurance platform", widget: "brands", label: "to theme a new client" },
    hook: {
      line: "A new client used to take weeks to set up.",
      turn: "With each client's brand in design tokens, it takes under a day.",
      note: "Illustration in a demo brand, not a client screen.",
      tabsLabel: "Three things that broke with every new client",
      picture: {
        visual: "client-theme",
        title: "A new client, before and after tokens",
        chips: ["Employer B, a new client"],
        before: {
          label: "Before: hardcoded",
          items: ["Brand color hardcoded: the old client's color stays", "Two buttons for the same job", "Rebuilt by hand for each client: weeks"],
        },
        after: {
          label: "With three-tier tokens",
          items: ["Color comes from the client's tokens", "One button, from the system", "Insurer → employer → member, themed in under a day"],
        },
      },
      findings: [
        {
          tab: "The color",
          words: "Brand colors were written straight into the code, so nothing could be re-themed.",
          source: "What I found in the existing product",
        },
        {
          tab: "The buttons",
          words: "Developers used different components for the same job on different pages.",
          source: "What I found in the existing product",
        },
        {
          tab: "The rebuild",
          words: "The business could only sign clients as fast as engineering could re-skin the product.",
          source: "The growth ceiling",
        },
      ],
    },
    hero: {
      label: "Enterprise platform",
      brief: "Adjust a handful of screens.",
      problem: "Every new client was rebuilt by hand because the product had no design system.",
      call: "Turn each client's brand into design tokens, and get engineering to build with them.",
    },
    snapshot: {
      frame: "I was asked for a few screen edits. The product had no design system: colors were hardcoded and every client was rebuilt by hand.",
      decision: "I put each client's brand into three-tier design tokens, and worked with engineering until building with them was the default.",
      outcome: "Theming a new client: weeks to under 24 hours. Delivery: about 2 days of design, 3 of build. Team-observed.",
    },
    frame: {
      assumed: "Change a few screens.",
      actual: "Every new client multiplied the cost of every change.",
      body: [
        "It was white-label: insurers resell it to employers, who show it to their members. Every level needs its own look.",
        "There was no system, and developers struggled to maintain what existed. Editing screens one by one would have kept it fragile.",
        "So I started by documenting what existed. That became the design system.",
      ],
      exhibit: "white-label-chain",
    },
    stakes: {
      intro: "It was failing in four ways.",
      items: [
        { title: "Inconsistency", body: "Different components for the same job on different pages." },
        { title: "Hardcoded colors", body: "Brand colors lived in the code, so nothing could be re-themed." },
        { title: "Rebuild per client", body: "Sales could only grow as fast as engineering could re-skin." },
        { title: "Compliance exposure", body: "In US health insurance, an inconsistent eligibility screen is a compliance risk." },
      ],
      exhibit: "growth-ceiling",
    },
    forks: [
      {
        id: "go-underneath",
        title: "I started with the foundation instead of the screen edits",
        tension: "The edits were the expected, visible move.",
        rejected: { label: "Do the edits", detail: "Every change stays hand-made; every client a rebuild." },
        chosen: { label: "Start with the foundation", detail: "Document what exists, and let that become the system." },
        why: ["Engineering felt the pain most, so they became the system's first users."],
        cost: "A foundation nobody asked for, which had to prove itself.",
        exhibit: "edits-vs-foundation",
      },
      {
        id: "brand-as-variable",
        title: "Each client's brand became a set of design tokens",
        tension: "Each client needs its own identity at three levels. Per-client builds would scale the mess.",
        rejected: { label: "Per-client builds", detail: "A separate copy of the look for every insurer and employer." },
        chosen: { label: "Three-tier tokens", detail: "Insurer → employer → member. Each tier overrides only what it owns." },
        why: ["A new client becomes configuration, not a project.", "One foundation runs web, mobile web, iOS, and Android."],
        cost: "Developers could no longer style things directly, and that habit took time to break.",
        exhibit: "theme-cascade",
      },
      {
        id: "adoption",
        title: "I treated adoption as part of the design work",
        tension: "At first developers carried on as before. The system lived in a file they had to remember to open.",
        rejected: { label: "Specs and good intentions", detail: "How the product became inconsistent in the first place." },
        chosen: { label: "Treat adoption as design", detail: "Work it from four sides until it's the default." },
        why: ["It took a few months:"],
        bullets: [
          { title: "Enablement", body: "Walkthroughs with developers." },
          { title: "Documentation", body: "Usage rules inside the system." },
          { title: "Quality", body: "Design QA catches hardcoded values before release." },
          { title: "Policy", body: "Agreed with the tech lead: the system is the standard." },
        ],
        cost: "Months of enablement and QA before it paid back.",
        exhibit: "adoption-four-sides",
      },
    ],
    followOn: {
      title: "How the work ran",
      items: [
        { title: "Personas", body: "Three to four each for insurers, employers, and members, from stakeholder research." },
        { title: "Workshops first", body: "New ideas went to a workshop with business analysts before design, so the rules were agreed first." },
        { title: "Architecture with engineering", body: "System changes were agreed with engineering before they shipped." },
      ],
      exhibit: "how-work-ran",
    },
    spotlight: {
      label: "Built on the token system",
      title: "The Branding Hub, where admins set each client's brand",
      intro: "Admins use the Branding Hub to set each employer's theme from the design tokens, check it on a real member dashboard, and assign it to employers. I designed it, and it's live.",
      why: [
        "Each employer needs the member portal in its own look.",
        "Someone has to set the tokens, for many employers, without breaking what members see.",
        "Several admins work on themes at once.",
      ],
      what: [
        "A hub of every theme: colors, employers using it, last editor, and draft, default, and locked states.",
        "An editor using the same roles as the tokens, each color saying where it appears.",
        "A preview on the member dashboard, then assignment to employers with their own logo and links.",
        "Drafts, an edit lock showing who's editing, change history, and restore.",
      ],
      impact: [
        "Shipped and used by admins.",
        "Theming a client is one admin task, inside the system.",
        "Colors are checked on a real dashboard before members see them.",
        "Admins don't overwrite each other, and deleted themes come back.",
      ],
      provenance: "Qualitative. Shipped; usage not formally measured.",
      exhibit: "branding-screens",
    },
    outcome: {
      metrics: [
        {
          value: "< 24 h",
          label: "To theme a new client",
          viz: {
            kind: "blocks",
            unit: "working day",
            before: { solid: 10, label: "weeks" },
            after: { solid: 1, label: "under a day" },
            note: "team-observed · weeks drawn at the low end",
          },
        },
        {
          value: "1–2 days",
          label: "To rebrand the white-label iOS and Android apps",
          viz: {
            kind: "timeline",
            end: 2,
            unit: "days",
            marks: [{ at: 2, label: "iOS and Android rebranded", accent: true }],
            note: "team-observed",
          },
        },
        {
          value: "2 + 3",
          label: "Days of design + build per feature, predictably",
          viz: {
            kind: "timeline",
            end: 5,
            unit: "days",
            marks: [
              { at: 2, label: "design" },
              { at: 5, from: 2, label: "build", accent: true },
            ],
            note: "working days · team-observed",
          },
        },
        {
          value: "120+",
          label: "Components on one foundation",
          viz: { kind: "fan", from: "120+ components", to: ["web", "mobile web", "iOS", "Android"], note: "one token set across four surfaces" },
        },
      ],
      points: [
        "Hardcoded colors and off-system components are caught in design QA, not in production.",
        "It serves Fortune-500 and enterprise-tier insurers.",
      ],
      provenance: "Team-observed, not formally tracked.",
      exhibit: "design-system-screens",
    },
    ownership: {
      mine: [
        "The reframe, the architecture, and the adoption plan.",
        "I started as the only designer, grew the team to four designers (I hired two), and became UX Lead.",
      ],
      change: [
        "I'd close the gap between the system and its users earlier. Its rationale lived in my head and in a file engineers had to check. Case 03 is how I later closed it.",
      ],
    },
    signals: "Finding the real problem, platform architecture with honest costs, and driving adoption across engineering.",
  },
  /* ------------------------------------------------------------------ 03 */
  {
    slug: "ai-readable-design-system",
    index: "03",
    glyph: "skills",
    group: "AI-driven UI",
    title: "Rewriting our design system so AI tools can follow it",
    short: "AI-readable design system",
    dek: "AI kept drawing screens that didn't look like our product, because six years of design rules lived only in designers' heads. I wrote them down as files the AI reads before it designs and checks its work against.",
    meta: {
      role: "UX Lead",
      context: "Mphasis · US health-insurance platform",
      timeline: "Built Aug–Sep 2026",
      domain: "Enterprise SaaS · US health insurance",
    },
    tags: ["Agentic design workflow", "Design systems", "Figma variables", "MCP"],
    headline: { value: "3–4 days", label: "from Jira story to engineering-ready screen, down from 1–2 weeks (team-observed)" },
    card: { title: "A design system AI can read", widget: "pipeline", label: "Jira-story turnaround" },
    hook: {
      line: "Our AI tool kept putting Save on the wrong side.",
      turn: "It had no way to know our rules, so I wrote them down. Then its screens matched our product.",
      note: "Illustration in a demo brand, not a client screen.",
      tabsLabel: "Three things the AI got wrong",
      picture: {
        visual: "same-request",
        title: "The same request, given to the AI twice",
        chips: ["Same AI", "Same components"],
        before: {
          label: "Before the skills",
          items: ["Save on the wrong side", "Link in a button color", "Side nav left out: docs said 19 components, the file had 20"],
        },
        after: {
          label: "With the skills",
          items: ["Save on the right", "Link takes the link color", "Side nav in place: audit matched docs to file, 20 of 20"],
        },
      },
      findings: [
        { tab: "The button", words: "", empty: "Button · Description", source: "The old button's description (as I remember it)" },
        { tab: "The color", words: "Not an exact match, but agreed mapping.", quoted: true, source: "The rebuilt system's note on an old color" },
        { tab: "The audit", words: "19 standalone components", quoted: true, source: "The system's index, before the audit (4 Sep 2026)" },
      ],
    },
    opener: {
      label: "Three things the AI got wrong",
      scope: "A six-year-old design system, five client brands, and three platforms, rewritten as files an AI reads before it designs.",
      note: "Illustrations with generic names, not client screens. Quotes come from the skill files.",
      stories: [
        {
          id: "save-side",
          tab: "The button",
          story: "The first one put Save on the left. Every designer here puts it on the right.",
          quoteEmpty: { field: "Button · Description" },
          quoteSource: "The old button's description (as I remember it)",
          visual: "save-side",
          caption: "The habit lived in our heads. Now it's one line the AI reads before every screen.",
        },
        {
          id: "link-colour",
          tab: "The color",
          story: "Our links have one color. The AI picked another.",
          quote: "Not an exact match, but agreed mapping.",
          quoteSource: "The rebuilt system's note on an old color",
          visual: "link-colour",
          caption: "The old colors were named for how they look, so any could be a link. Now each is named for its job.",
        },
        {
          id: "audit",
          tab: "The audit",
          story: "Even with the rules written down, the docs said 19 components. The file had 20.",
          quote: "19 standalone components",
          quoteSource: "The system's index, before the audit (4 Sep 2026)",
          visual: "audit",
          caption: "Unchecked patches are how the old system drifted. Now an audit compares docs and file every session.",
        },
      ],
    },
    hero: {
      label: "AI-driven design system",
      brief: "The AI isn't good enough yet. Prompt harder.",
      problem: "The six-year-old design system lived in designers' heads, so the AI couldn't follow it.",
      call: "Rewrite it as skill files the AI reads and checks its work against.",
    },
    snapshot: {
      frame: "We were using AI to draft screens, and the drafts didn't match our product. Our design rules lived in designers' heads, so the AI had nothing to follow.",
      decision: "Without being asked, I rewrote the design system as skill files the AI reads before it designs.",
      outcome: "Mockups: 2 days to 3–4 hours. Jira stories: 1–2 weeks to 3–4 days. Adopted beyond my team. Team-observed.",
    },
    frame: {
      assumed: "The AI isn't good enough yet.",
      actual: "Our design system was never written down for a machine.",
      body: [
        "Sales demos and handoffs from business analysts to developers both waited on mockups. I brought in AI to speed them up. Its screens weren't usable.",
        "Our Figma system was six years old, with no descriptions. The rules lived in designers' heads, so the AI had components but no rules.",
        "No one had made a veteran system AI-readable. I found no process, so I built one.",
      ],
      exhibit: "rules-in-heads",
    },
    stakes: {
      intro: "Two teams were waiting on fast, on-brand screens.",
      items: [
        { title: "Business analysts and developers", body: "Developers judge feasibility from screens, not specs." },
        { title: "Sales and marketing", body: "Slow branded demos slipped in live sales cycles." },
        { title: "Senior design time", body: "Every hand-drawn mockup pulled seniors off product work." },
      ],
      exhibit: "two-loops",
    },
    forks: [
      {
        id: "fix-the-system",
        title: "I rewrote the design system instead of tuning the prompts",
        tension: "The expected answers: wait for better AI, prompt harder, or hire. Nobody asked for a rebuild.",
        rejected: { label: "Tune the prompts", detail: "Coax better output from the same system." },
        chosen: { label: "Make the system legible", detail: "Rewrite it so a machine can follow it." },
        why: [
          "I'd been watching agent-readable docs emerge. I couldn't change the AI. I could change the system.",
          "No one assigned it; I took it on.",
        ],
        cost: "Weeks of unasked work before it proved itself.",
        exhibit: "prompt-vs-system",
      },
      {
        id: "skill-files",
        title: "I wrote the system as linked skill files, built up from tokens",
        tension: "An agent needs rules, not a component count: which color for a link, which grid for a page.",
        rejected: { label: "Richer Figma descriptions", detail: "Annotate the file and hope the agent infers the rest." },
        chosen: { label: "Interlocking skill files", detail: "Plain-markdown skills, built up from tokens." },
        why: [
          "One system themes five client brands by mode: semantic color, type by use, a 12-column grid, 43 component sets, 3 density modes, and 141 described variables.",
          "Tokens first, then components that know their tokens, so it stays consistent as it grows.",
        ],
        cost: "More upfront work than annotating what existed.",
        exhibit: "skill-graph",
      },
      {
        id: "structural-correctness",
        title: "I made the AI build from real components and check its own work",
        tension: "Even with tokens, grid, and components written down, the output still broke.",
        rejected: { label: "Accept good-looking output", detail: "Screens that pass a glance but aren't wired to the system." },
        chosen: { label: "Enforce structure", detail: "App shells, a self-checking build workflow, real instances." },
        why: ["Three fixes mattered most:"],
        bullets: [
          { title: "Composition", body: "App shells and a build workflow: pick the shell, use only approved components, run a checklist." },
          { title: "A growing system", body: "The skills say when to reuse, when to add a variant, and when to build new." },
          { title: "Instances, not redraws", body: "Agents redraw elements from scratch. Every element is now a real instance: cheaper and traceable." },
        ],
        cost: "Slower first runs, for output that meets the bar.",
        exhibit: "build-screen",
      },
      {
        id: "portable",
        title: "I kept the skill files portable, so any AI tool can use them",
        tension: "Figma's agent was free in beta. Beta pricing ends.",
        rejected: { label: "Go all-in on one vendor", detail: "A format only one agent can read." },
        chosen: { label: "Portable and self-maintaining", detail: "Plain markdown, any agent, with drift checks and memory." },
        why: [
          "Anti-drift: an audit compares the file with the docs, and a memory skill carries decisions forward.",
          "Anti-lock-in: it runs on Figma's agent today and can move to Claude Code or any agent through a Figma MCP.",
        ],
        cost: "Governance to maintain: versioned backups and a guide page.",
        exhibit: "portable-skills",
      },
    ],
    outcome: {
      metrics: [
        {
          value: "3–4 h",
          label: "New-client and demo mockups",
          before: { label: "~2 days", amount: 16 },
          after: { label: "3–4 hours", amount: 3.5 },
          unit: "working hours",
          visual: "mockup-hours",
        },
        {
          value: "3–4 days",
          label: "Jira story to engineering-ready screen, with business analysts",
          before: { label: "1–2 weeks", amount: 7.5 },
          after: { label: "3–4 days", amount: 3.5 },
          unit: "working days",
          visual: "story-days",
        },
        { value: "~40%", label: "Less design production time overall", visual: "time-freed" },
        { value: "5 · 3", label: "Client brands and platforms covered by one system", visual: "brand-grid" },
      ],
      points: [
        "All four designers on my team use it, and the org's UAT team chose it for their projects. I didn't have to sell it.",
        "The AI drafts the screens and designers make the decisions. The time saved goes to research, flows, and edge cases.",
        "Built in 4–5 weeks across five brands and three platforms. I could redo it in 1–2.",
      ],
      provenance: "Team-observed figures, recognized by managers, business analysts, and leadership. Not yet in sprint metrics.",
      exhibit: "adoption-spread",
    },
    ownership: {
      mine: [
        "Self-initiated. I built it, proved it, then brought the team in.",
        "I haven't handed it to business analysts yet: they'd likely skip the UX thinking. That's on purpose.",
      ],
      change: ["I'd track before and after from day one, so the gains are measured, not just acknowledged."],
    },
    signals: "A design system alone won't drive an AI. Teach it your rules, and turn every repeated mistake into a skill.",
  },
  /* ------------------------------------------------------------------ 04 */
  {
    slug: "designing-trust-into-ai",
    index: "04",
    glyph: "pipeline",
    group: "AI-driven UI",
    title: "Blinkwiser: making an AI carousel tool you can check",
    short: "Blinkwiser AI carousels",
    dek: "The first version took two weeks and made up its own statistics. Over the next two months, building with AI coding agents, I rebuilt it so every number traces to a source and every edit can be undone.",
    meta: {
      role: "Independent lab · product, UX, architecture, evaluation",
      context: "Blinkwiser · built by directing AI coding agents",
      timeline: "Jul 2026–present",
      domain: "AI SaaS · creator tools",
    },
    tags: ["Agent pipeline", "Grounding", "Eval harness", "AI UX"],
    cover: {
      src: "/work/blinkwiser/landing.webp",
      width: 1600,
      height: 1090,
      alt: "Agentic Carousel by Blinkwiser landing page: 'Carousels that design themselves', a prompt box, and a fan of generated slides in three styles.",
      caption: "Agentic Carousel by Blinkwiser, live: agents research, write, and design a LinkedIn carousel from a topic, link, video, or file.",
    },
    reel: {
      video: "/work/blinkwiser/run.mp4",
      poster: "/work/blinkwiser/run-poster.webp",
      width: 1600,
      height: 800,
      alt: "Screen recording of the studio generating a carousel: each agent step reports in the chat, then the first slides land, marked Draft while the editor is still checking.",
      caption: "One run, sped up 3×: each agent step reports in the chat, and the first slides land marked Draft while the checks finish.",
    },
    headline: { value: "7 in 10", label: "blind comparisons won by the rebuild over the first version (my eval harness, AI judge)" },
    card: { title: "Blinkwiser AI carousels", widget: "slides", value: "Plan → Reflect", label: "facts checked before you see it" },
    hook: {
      line: "The first version made up its own statistics.",
      turn: "I rebuilt it in two months, so every number traces to a source and every edit can be undone.",
      number: { value: "7 in 10", label: "blind head-to-heads won by the rebuild over v1 (my eval harness, AI judge)" },
      note: "Illustration with demo content, not a real deck. The live product is shown below.",
      tabsLabel: "Three ways v1 broke trust",
      picture: {
        visual: "trust-edit",
        title: "One edit, in v1 and in the rebuild",
        chips: ["One edit request", "v1 vs the rebuild"],
        before: {
          label: "v1",
          items: ["A number with no source", "Claimed an edit it hadn't made", "No way back: undo was a chat message"],
        },
        after: {
          label: "The rebuild",
          items: ["Every number traces to a source", "Says what didn't change, then retries", "Every change saves a restore point"],
        },
      },
      findings: [
        { tab: "The number", words: "The model invented numbers and stated them with confidence.", source: "What broke in use" },
        { tab: "The claim", words: "I've rewritten the carousel", quoted: true, source: "v1's chat, when nothing had changed" },
        { tab: "The way back", words: "Undo was a chat message, not a restore point.", source: "What broke in use" },
      ],
    },
    hero: {
      label: "AI product · founder",
      brief: "Turn a topic into a LinkedIn carousel, fast.",
      problem: "Creators couldn't trust the numbers the AI wrote, or its claims about what it changed.",
      call: "Check every fact in code, and make every edit undoable.",
    },
    snapshot: {
      frame: "The model made up numbers, claimed edits it hadn't made, and drifted into generic AI writing. Creators couldn't trust what it produced.",
      decision: "I moved the rules from the prompt into code, made every edit reversible and clear about what changed, and settled trade-offs with blind tests.",
      outcome: "Numbers trace to sources, the chat says what really changed, and every edit can be undone. Live, free, pre-revenue.",
    },
    frame: {
      assumed: "Generation is the product.",
      actual: "People post these carousels under their own name, so every fact has to be right.",
      body: [
        "The brief was my own. A first version was in beta within two weeks. The hard part showed up in use.",
        "A wrong statistic costs a creator their reputation. A tool that lies about its own edits can't be trusted with anything.",
      ],
      exhibit: "trust-questions",
    },
    stakes: {
      items: [
        { title: "Creators publish under their own name", body: "Accuracy isn't a nice-to-have." },
        { title: "An AI editor lives on honesty", body: "If the chat misreports a change, people stop believing it." },
        { title: "Speed decides who stays", body: "Every extra quality step adds time." },
        { title: "Solo and bootstrapped", body: "Cost per deck matters as much as quality." },
      ],
      exhibit: "quality-steps",
    },
    forks: [
      {
        id: "enforce-in-code",
        title: "I moved the rules from the prompt into code",
        tension: "v1 relied on prompts. Limits and “don't make things up” were requests the model could ignore.",
        rejected: { label: "Better prompts", detail: "Keep asking, and hope." },
        chosen: { label: "A checked pipeline", detail: "Anything that must be true is checked in code." },
        why: [
          "Research becomes a numbered fact sheet. An outline fixes the slide count and assigns facts to slides.",
          "Every number must trace to a source, or its slide is downgraded. A critic and a fact-checker review in parallel.",
        ],
        cost: "More calls and more waiting, which forced decision 3.",
        exhibit: "pipeline",
      },
      {
        id: "honest-reversible",
        title: "Every change is checked and can be undone",
        tension: "The editor became a chat agent, so honesty became critical.",
        rejected: { label: "Relay the model's claim", detail: "Show whatever the agent says it did." },
        chosen: { label: "Honesty guard and restore points", detail: "State what didn't change; checkpoint every change." },
        why: [
          "When the model claims an edit it didn't make, a guard says so and retries.",
          "Every change saves a restore point. Restoring trims later turns from the agent's memory.",
        ],
        cost: "A more complex conversation model to build and test.",
        exhibit: "restore-chat",
      },
      {
        id: "evidence-not-taste",
        title: "I settled quality versus speed with blind tests",
        tension: "v2 was more accurate but slower: 84 seconds a deck.",
        rejected: { label: "Guess", detail: "Pick a setting by feel." },
        chosen: { label: "A blind eval harness", detail: "10 golden cases, a blind judge, head-to-heads." },
        why: [
          "I fixed the judge first: it was marking sourced numbers as invented.",
          "Reasoning off held quality (8.0 vs 8.1) and cut a deck from 84 to 31 seconds, at about half the cost.",
        ],
        cost: "Time on measurement instead of features.",
        exhibit: "blind-eval",
      },
      {
        id: "protect-design",
        title: "I cut the extra features to protect the templates",
        tension: "I built a freeform canvas and a looks system: nine styles, plus font and layout pickers.",
        rejected: { label: "Ship the flexibility", detail: "More knobs, more generic output." },
        chosen: { label: "Cut them", detail: "Three templates, exactly as designed: The Truth, The Sketch, The Statement." },
        why: ["Flexibility made every template look generic."],
        cost: "Throwing away finished work.",
        exhibit: "cut-to-three",
      },
    ],
    outcome: {
      metrics: [
        {
          value: "7 / 10",
          label: "Blind head-to-heads won by the rebuild over v1",
          viz: { kind: "dots", filled: 7, total: 10, note: "my eval harness · AI judge" },
        },
        {
          value: "9.5 vs 8.8",
          label: "Accuracy: claims that hold up against their sources",
          viz: {
            kind: "compare",
            rows: [
              { label: "rebuild", value: 9.5, accent: true },
              { label: "v1", value: 8.8 },
            ],
            max: 10,
            note: "AI judge, scored against the evidence",
          },
        },
        {
          value: "31 s",
          label: "Per carousel, down from 84 s, same quality",
          viz: {
            kind: "compare",
            rows: [
              { label: "before", value: 84 },
              { label: "now", value: 31, accent: true },
            ],
            max: 84,
            note: "seconds per deck · my harness",
          },
        },
        {
          value: "~23 s",
          label: "Until the first slides appear, marked Draft",
          viz: {
            kind: "timeline",
            end: 31,
            unit: "s",
            marks: [
              { at: 23, label: "first slides, Draft", accent: true },
              { at: 31, label: "checks done" },
            ],
            note: "a typical run · checks finish after first slides",
          },
        },
      ],
      points: [
        "Every change saves a restore point, and the chat says when an edit didn't happen.",
        "Still behind: v1 scores higher on flow (8.4 vs 7.5). That's next.",
        "Live and free at blinkwiser.com, with a handful of real users and no revenue yet.",
      ],
      provenance: "Scores come from my own harness and an AI judge, not from users.",
      exhibit: "eval-board",
    },
    ownership: {
      mine: [
        "Product, UX, pipeline architecture, eval design, and every cut.",
        "Built by directing AI coding agents and holding them to tests and evals.",
      ],
      change: [
        "I rebuilt v2 on my own evals before real users told me what mattered. I'd ship to creators earlier and take distribution as seriously as quality.",
      ],
    },
    signals: "Designing for model failure, deciding trade-offs with evals, and the restraint to cut.",
  },
  /* ------------------------------------------------------------------ 05 */
  {
    slug: "dubai-municipality",
    index: "05",
    glyph: "services",
    group: "Civic scale",
    title: "Dubai Municipality: one place for a city's services",
    short: "Dubai Municipality",
    dek: "Every service had its own rules, and each department wanted its services up front. I organized them by what residents need done, in Arabic and English.",
    meta: {
      role: "Lead UX Designer, onsite in Dubai",
      context: "Mphasis · Dubai Municipality",
      timeline: "2020–2021",
      domain: "Government · bilingual English–Arabic",
    },
    tags: ["Information architecture", "Stakeholder alignment", "RTL design", "Low-code constraints"],
    cover: {
      src: "/work/dubai/app.webp",
      width: 2400,
      height: 1273,
      full: true,
      alt: "Four screens of the Dubai Municipality app: the home screen in English and in Arabic, the Services screen grouped by need, and the Dashboard tracking every request.",
      caption: "The live app: search first, services grouped by need, one dashboard for every request, and Arabic equal to English.",
    },
    headline: { value: "", label: "One place for city services, for citizens and residents, in Arabic and English" },
    card: { title: "Dubai Municipality app", widget: "departments", label: "for citizens and residents" },
    hook: {
      line: "Residents don't know who owns a service.",
      turn: "So I organized the city's services by what people need done.",
      note: "Illustration with generic labels, not the client's screens. The live app is shown below.",
      tabsLabel: "Three things the old catalog got wrong",
      picture: {
        visual: "city-home",
        title: "The services screen, before and after",
        chips: ["Every city service", "Arabic and English"],
        before: {
          label: "Organized by department",
          items: ["Grouped by who owns the service", "Found only by its official name", "Each service laid out its own way"],
        },
        after: {
          label: "Organized by need",
          items: ["Grouped by what residents need", "Search first: say what you need", "One pattern: eligibility, documents, fees, status"],
        },
      },
      findings: [
        {
          tab: "The grouping",
          words: "A resident renewing a permit doesn't know or care which department owns it.",
          source: "Why the catalog had to change",
        },
        { tab: "The name", words: "People rarely know a service's official name.", source: "Why search became the front door" },
        {
          tab: "The pattern",
          words: "Each service had its own rules, documents, fees, and approval chain.",
          source: "The catalog, as it was",
        },
      ],
    },
    hero: {
      label: "Civic services · bilingual",
      brief: "Redesign the city's services portal.",
      problem: "Services were grouped by department, but residents only know what they need done.",
      call: "Group services by what residents need, in Arabic and English equally.",
    },
    snapshot: {
      frame: "The brief was a portal redesign. Services were grouped by department, but residents only know what they need done.",
      decision: "I organized every service by resident need, in one pattern the client's low-code platform could build, with Arabic and English as equals.",
      outcome: "One home for every service, search first, and one dashboard for every request. Signed off at every milestone and built as designed.",
    },
    frame: {
      assumed: "Redesign the portal's look.",
      actual: "Decide how a city's services are organized for residents, then defend it.",
      body: [
        "Permits, complaints, bookings, waste, and more, for citizens and residents, in Arabic and English.",
        "Each service had its own rules, fees, and approvals, and a department expecting prominence.",
      ],
      exhibit: "org-vs-need",
    },
    stakes: {
      items: [
        { title: "Residents succeed alone", body: "Two languages, a diverse city, no onboarding." },
        { title: "Formal sign-off at every step", body: "Milestone approvals, where ambiguity means delay." },
        { title: "Built in low-code", body: "Mendix has a fixed set of components, so every design had to be buildable with them." },
        { title: "Moving requirements", body: "The structure had to absorb change without a redesign." },
      ],
      exhibit: "four-constraints",
    },
    forks: [
      {
        id: "resident-need",
        title: "I grouped services by what residents need done",
        tension: "Each department wanted its services up front. By department was the easiest to sign off.",
        rejected: { label: "By department", detail: "Easy to approve, worst for residents." },
        chosen: { label: "By resident need", detail: "Search first, and one place to track every request." },
        why: [
          "People rarely know a service's official name, so search became the front door.",
          "Mapping every service first gave me the evidence to defend it in review.",
        ],
        cost: "No department got its own front door. I defended that at every milestone.",
        exhibit: "service-map",
      },
      {
        id: "service-pattern",
        title: "Every service follows one template",
        tension: "A design per service would copy each one's inconsistency and multiply the build.",
        rejected: { label: "Bespoke per service", detail: "Every service a one-off." },
        chosen: { label: "One service template", detail: "Eligibility, documents, fees, steps, and status, always in the same place." },
        why: ["One pattern for residents and for the build team. A new service slots in without reopening the design."],
        cost: "Some services had to fit a shared shape.",
        exhibit: "bilingual-pair",
      },
      {
        id: "buildable",
        title: "I designed within what the client's low-code platform could build",
        tension: "I wanted custom navigation and components Mendix didn't support.",
        rejected: { label: "The ideal", detail: "A great Figma file and a stalled build." },
        chosen: { label: "The buildable", detail: "Redesign inside the platform's set, checked with the client's team." },
        why: ["Arabic and English were designed side by side from the first wireframe, so right-to-left issues surfaced early."],
        cost: "Some navigation ideas I liked.",
        exhibit: "ideal-vs-buildable",
      },
    ],
    outcome: {
      metrics: [
        {
          value: "One home",
          label: "For every service, grouped by need, not department",
          viz: { kind: "fan", from: "one home", to: ["permits", "complaints", "bookings", "waste"], note: "service types from the brief" },
        },
        {
          value: "One place",
          label: "To track every request",
          viz: {
            kind: "fan",
            from: "one dashboard",
            to: ["in progress", "completed", "canceled", "waiting on payment"],
            note: "request states, as shipped",
          },
        },
        {
          value: "Every",
          label: "Milestone formally signed off",
          viz: { kind: "ticks", count: 5, label: "signed off at every review", note: "number of ticks drawn, not counted" },
        },
        {
          value: "Arabic + English",
          label: "For citizens and residents, designed side by side",
          viz: { kind: "fan", from: "one app", to: ["English", "Arabic"], note: "designed side by side from the first wireframe" },
        },
      ],
      points: [
        "Built by the client's own team in Mendix, with no custom workarounds.",
        "Arabic designed with English from the first wireframe: no right-to-left rework.",
      ],
      provenance: "This was 2020–2021. The live app has changed a lot since; this is what we designed and shipped then.",
    },
    ownership: {
      mine: [
        "Lead UX designer onsite in Dubai. I led the design team, presented every milestone to senior officials, and defended the structure.",
      ],
      change: [
        "I'd test the Arabic with Arabic-speaking residents, not just officials.",
        "I'd write down our right-to-left rules so the next bilingual team doesn't start from zero.",
      ],
    },
    signals: "Structure in a political room, designing for the real build, and bilingual right-to-left as a first-class discipline.",
  },
  {
    slug: "jet-airways-booking",
    index: "06",
    glyph: "flow",
    group: "Consumer e-commerce",
    title: "Jet Airways: booking a flight, from fare to payment",
    short: "Jet Airways booking",
    dek: "Five fares per flight, add-ons to sell, and three platforms to cover. I designed how people choose a fare, see the full price, and add extras, on web, iOS, and Android.",
    meta: {
      role: "UX Designer, on a larger team",
      context: "Mphasis · Jet Airways",
      timeline: "2015–2019",
      domain: "Airline e-commerce · web, iOS, Android",
    },
    tags: ["E-commerce checkout", "Pricing clarity", "Upsell and add-ons", "Responsive design"],
    cover: {
      src: "/work/jet/overview.webp",
      width: 2321,
      height: 1782,
      full: true,
      alt: "Jet Airways booking screens: the desktop fare grid with five fares per flight, the JetBistro meal picker, and the mobile flight list with one flight opened to show its fares.",
      caption: "The booking flow as it shipped: the fare grid on desktop, the same choice as a list on mobile, and meals picked per passenger.",
      note: "Real screens from the shipped product, from my own files.",
    },
    headline: { value: "", label: "Booking on web, iOS, and Android, live until the airline closed in 2019" },
    hook: {
      line: "Five fares per flight don't fit on a phone.",
      turn: "So on mobile, each flight opens to show its fares as a list.",
      note: "Illustration with demo content, not the airline's screens. The real screens are shown below.",
      tabsLabel: "Three things a shrunk grid gets wrong",
      picture: {
        visual: "fare-choice",
        title: "Choosing a fare on a phone",
        chips: ["Same five fares", "Same flight"],
        before: {
          label: "The desktop grid, shrunk",
          items: ["Five fare columns squeezed side by side", "Prices too small to compare", "No room for seats left or the saving"],
        },
        after: {
          label: "Tap a flight, then pick a fare",
          items: ["One flight opens at a time", "Each fare gets a full-width row", "Seats left and the old price sit with the fare"],
        },
      },
      findings: [
        { tab: "The columns", words: "A grid that works on a wide screen turns into five narrow columns on a phone.", source: "Why mobile needed its own layout" },
        { tab: "The prices", words: "People choose a fare by price, so the price has to be easy to read.", source: "What the list fixes" },
        { tab: "The details", words: "Seats left and the price before discount help people decide, and need room.", source: "What the list makes room for" },
      ],
    },
    hero: {
      label: "Airline e-commerce",
      brief: "Design the booking screens.",
      problem: "Five fares, add-ons, and three platforms made one booking a lot of choices.",
      call: "Make each choice clear: the fare, the full price, and the extras.",
    },
    snapshot: {
      frame: "Booking a flight meant choosing between five fares per flight, then adding extras, on web, iOS, and Android.",
      decision: "I designed a fare grid for desktop and a list for mobile, a full price breakdown, one step for every add-on, and the upgrade offer inside the fare choice.",
      outcome: "Shipped on web, iOS, and Android on a shared component library, and live until the airline closed in 2019.",
    },
    frame: {
      assumed: "Design the booking screens.",
      actual: "Help people choose a fare they understand, on any screen, with no surprises at payment.",
      body: [
        "I worked on Jet Airways' booking for four years, on a larger design team. There was no single brief: the work came in pieces, across the whole journey.",
        "The journey ran Search, Flights, Guests, Extras, Pay. This case covers four calls I made along it.",
      ],
      exhibit: "jet-journey",
    },
    stakes: {
      items: [
        { title: "Many choices at once", body: "Each flight came in five fares, plus a business-class option." },
        { title: "Price decides", body: "People compare fares by price, so every number has to be clear." },
        { title: "Extras matter to the airline", body: "Meals, seats, baggage, and insurance were sold during booking." },
        { title: "Three platforms", body: "Web, iOS, and Android had to offer the same choices, each in a way that fits the screen." },
      ],
    },
    forks: [
      {
        id: "grid-and-list",
        title: "I kept the fare grid on desktop and turned it into a list on mobile",
        tension: "The grid works on a wide screen. On a phone, five fare columns don't fit.",
        rejected: { label: "One layout everywhere", detail: "Shrink the grid to fit the phone." },
        chosen: { label: "A grid on desktop, a list on mobile", detail: "Each flight opens to show its fares as full-width rows." },
        why: [
          "On desktop, people compare flights and fares at a glance in one grid.",
          "On a phone, one flight opens at a time, so every fare has room for its price, the old price, and seats left.",
        ],
        cost: "Two layouts for the same choice, to design and keep in step.",
        exhibit: "grid-vs-list",
      },
      {
        id: "full-price",
        title: "I showed the full price, broken down, while people choose",
        tension: "One total is simpler to show. It also hides what the money is for.",
        rejected: { label: "Total only", detail: "One number, explained later, if at all." },
        chosen: { label: "The total, broken down", detail: "Fare, tax, fees, and discount in a trip summary beside the flights." },
        why: [
          "The trip summary sits next to the fare choice, so people see what they'll pay before they move on.",
          "Every fee has a line of its own, so the total at payment isn't a surprise.",
        ],
        cost: "A longer summary panel, competing with the flight list for space.",
        exhibit: "total-vs-breakdown",
      },
      {
        id: "extras-step",
        title: "I put every add-on in one step before payment",
        tension: "Each add-on could have been its own step, or a pop-up along the way.",
        rejected: { label: "Add-ons spread through the flow", detail: "A step or a pop-up for each one." },
        chosen: { label: "One Extras step", detail: "Meals, seats, baggage, priority, miles, and insurance, in one list before pay." },
        why: [
          "People see every add-on once, choose what they want, and move on.",
          "Meals are chosen per passenger and per flight, with filters such as veg, hot meals, and snacks.",
        ],
        cost: "One longer step, so each add-on stays closed until someone opens it.",
        exhibit: "extras-one-step",
      },
      {
        id: "upsell-inline",
        title: "I put the business-class offer inside the fare choice",
        tension: "Upgrades are often sold with a pop-up that interrupts the choice.",
        rejected: { label: "A pop-up offer", detail: "Stops people mid-choice to sell the upgrade." },
        chosen: { label: "An offer in place", detail: "Shown under the chosen fare, with what it adds and how much more it costs." },
        why: [
          "The offer appears where people are already comparing, in the same terms: what you get and the price difference.",
          "Saying no takes no extra click.",
        ],
        cost: "Quieter than a pop-up, so the offer has to win on what it shows: wider seats and better meals.",
        exhibit: "upsell-inline",
      },
    ],
    outcome: {
      metrics: [
        {
          value: "3 platforms",
          label: "Web, iOS, and Android, on a shared component library",
          viz: { kind: "fan", from: "one library", to: ["web", "iOS", "Android"], note: "platforms, as shipped" },
        },
        {
          value: "5 steps",
          label: "Search, flights, guests, extras, pay",
          viz: { kind: "fan", from: "one booking", to: ["search", "flights", "guests", "extras", "pay"], note: "the booking steps, as shipped" },
        },
        {
          value: "6 add-ons",
          label: "In one step before payment",
          viz: { kind: "fan", from: "one Extras step", to: ["meals", "seats", "baggage", "priority", "miles", "insurance"], note: "add-ons, as shipped" },
        },
        {
          value: "Until 2019",
          label: "Live in production until the airline closed",
          viz: { kind: "ticks", count: 5, label: "2015 to 2019", note: "one mark per year" },
        },
      ],
      points: [
        "Built on a shared component library, so web, iOS, and Android offered the same choices.",
        "The same choices worked on desktop and on a phone, each laid out for its screen.",
      ],
      provenance: "This was 2015–2019 and I have no figures from it. These are what we designed and shipped.",
      exhibit: "jet-screens",
    },
    ownership: {
      mine: [
        "The four calls above: the grid and the mobile list, the price breakdown, the single Extras step, and the in-place upgrade offer.",
      ],
      shared: [
        "I was on a larger design team for the airline's digital products. Other designers on the team owned the rest of the journey.",
      ],
      change: [
        "I'd measure as I went: how many people picked each fare, and how many added extras, so the work could be judged by numbers.",
        "I'd watch people book on a phone, not just review the screens.",
      ],
    },
    signals: "Pricing people can trust, choices that fit the screen, and selling without getting in the way.",
  },
];

export const getCaseStudy = (slug: string) => caseStudies.find((c) => c.slug === slug);

export const getNeighbours = (slug: string) => {
  const i = caseStudies.findIndex((c) => c.slug === slug);
  const n = caseStudies.length;
  return {
    prev: caseStudies[(i - 1 + n) % n]!,
    next: caseStudies[(i + 1) % n]!,
  };
};
